from django.urls import path
from . import views

urlpatterns = [
    path('crear/', views.crear_envio, name='crear_envio'),
]
